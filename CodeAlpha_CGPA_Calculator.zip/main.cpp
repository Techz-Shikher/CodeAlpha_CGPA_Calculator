#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

struct Course {
    string name;
    float grade;
    int credit;
};

float calculateCGPA(const vector<Course>& courses) {
    float totalGradePoints = 0.0;
    int totalCredits = 0;

    for (const auto& course : courses) {
        totalGradePoints += course.grade * course.credit;
        totalCredits += course.credit;
    }

    return totalCredits ? (totalGradePoints / totalCredits) : 0.0;
}

int main() {
    int n;
    cout << "Enter number of courses: ";
    cin >> n;

    vector<Course> courses(n);
    for (int i = 0; i < n; ++i) {
        cout << "\nEnter name of course " << i + 1 << ": ";
        cin >> ws;
        getline(cin, courses[i].name);

        cout << "Enter grade for " << courses[i].name << ": ";
        cin >> courses[i].grade;

        cout << "Enter credit hours for " << courses[i].name << ": ";
        cin >> courses[i].credit;
    }

    float cgpa = calculateCGPA(courses);

    cout << "\n--- Course Report ---\n";
    cout << left << setw(20) << "Course" << setw(10) << "Grade" << setw(10) << "Credit" << endl;
    for (const auto& c : courses) {
        cout << left << setw(20) << c.name << setw(10) << c.grade << setw(10) << c.credit << endl;
    }

    cout << fixed << setprecision(2);
    cout << "\nFinal CGPA: " << cgpa << endl;

    return 0;
}